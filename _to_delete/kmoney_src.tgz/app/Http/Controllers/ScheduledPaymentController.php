<?php

namespace App\Http\Controllers;

use App\Mail\RecurringPaymentScheduled;
use App\Models\Account;
use App\Models\ScheduledPayment;
use App\Models\User;
use App\Services\ScheduledPaymentService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class ScheduledPaymentController extends Controller
{
    public function __construct(
        private readonly ScheduledPaymentService $service,
    ) {}

    // ── Index ─────────────────────────────────────────────────────────────────

    public function index(Request $request): View|RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $filters = $this->scheduledPaymentFilters($request);

        $query = ScheduledPayment::query()
            ->with(['toAccount.company', 'fromAccount.company', 'transfer']);

        // Direzione: uscite (from), entrate (to), oppure entrambe
        if ($filters['direction'] === 'out') {
            $query->where('from_account_id', $currentAccount->id);
        } elseif ($filters['direction'] === 'in') {
            $query->where('to_account_id', $currentAccount->id);
        } else {
            $query->where(fn ($q) => $q
                ->where('from_account_id', $currentAccount->id)
                ->orWhere('to_account_id', $currentAccount->id)
            );
        }

        // Stato
        if ($filters['status'] !== '') {
            $query->where('status', $filters['status']);
        }

        // Data da / data a (su scheduled_at)
        if ($filters['date_from'] !== '') {
            $query->where('scheduled_at', '>=', $filters['date_from'] . ' 00:00:00');
        }
        if ($filters['date_to'] !== '') {
            $query->where('scheduled_at', '<=', $filters['date_to'] . ' 23:59:59');
        }

        // Ricerca per nome controparte
        if ($filters['search'] !== '') {
            $term = $filters['search'];
            $query->where(function ($q) use ($currentAccount, $term, $filters): void {
                // Cerca nel destinatario (pagamenti in uscita o entrambi)
                if ($filters['direction'] !== 'in') {
                    $q->orWhereHas('toAccount.company', fn ($cq) =>
                        $cq->where('name', 'like', "%{$term}%")
                    );
                }
                // Cerca nel mittente (pagamenti in entrata o entrambi)
                if ($filters['direction'] !== 'out') {
                    $q->orWhereHas('fromAccount.company', fn ($cq) =>
                        $cq->where('name', 'like', "%{$term}%")
                    );
                }
            });
        }

        $payments = $query->latest('scheduled_at')->paginate(20)->withQueryString();

        return view('portal.scheduled-payments.index', [
            'pageTitle'      => 'Pagamenti programmati',
            'currentAccount' => $currentAccount,
            'payments'       => $payments,
            'filters'        => $filters,
            'pendingCount'   => ScheduledPayment::where('from_account_id', $currentAccount->id)
                ->where('status', 'pending')->count(),
            'activeNav'      => 'scheduled-payments',
        ]);
    }

    protected function scheduledPaymentFilters(Request $request): array
    {
        $status    = trim((string) $request->query('status', ''));
        $direction = trim((string) $request->query('direction', ''));
        $search    = trim((string) $request->query('search', ''));

        return [
            'status'    => in_array($status, ['pending', 'executed', 'cancelled', 'failed'], true) ? $status : '',
            'direction' => in_array($direction, ['in', 'out'], true) ? $direction : '',
            'search'    => mb_substr($search, 0, 100),
            'date_from' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $request->query('date_from', '')) ? $request->query('date_from') : '',
            'date_to'   => preg_match('/^\d{4}-\d{2}-\d{2}$/', $request->query('date_to', ''))   ? $request->query('date_to')   : '',
        ];
    }

    // ── Create ────────────────────────────────────────────────────────────────

    public function create(Request $request): View|RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $counterparties = Account::query()
            ->with(['company', 'ownerUser'])
            ->where('status', 'active')
            ->whereKeyNot($currentAccount->id)
            ->whereNotNull('company_id')
            ->orderBy('id')
            ->get();

        return view('portal.scheduled-payments.create', [
            'pageTitle'      => 'Programma un pagamento',
            'currentAccount' => $currentAccount,
            'counterparties' => $counterparties,
            'activeNav'      => 'scheduled-payments',
        ]);
    }

    // ── Store ─────────────────────────────────────────────────────────────────

    public function store(Request $request): RedirectResponse
    {
        [$currentAccount, $currentUser] = $this->resolveCurrentContext($request->user());

        $isRecurring = $request->boolean('is_recurring');

        if ($isRecurring) {
            return $this->storeRecurring($request, $currentAccount, $currentUser);
        }

        $request->merge(['amount' => str_replace(',', '.', (string) $request->input('amount'))]);

        $data = $request->validate([
            'to_account_id' => ['required', 'integer', 'exists:accounts,id'],
            'amount'        => ['required', 'numeric', 'min:0.01', 'max:9999999'],
            'description'   => ['required', 'string', 'min:3', 'max:500'],
            'scheduled_at'  => ['required', 'date', 'after:now'],
        ]);

        abort_if((int) $data['to_account_id'] === $currentAccount->id, 422, 'Non puoi programmare un pagamento a te stesso.');

        $toAccount = Account::findOrFail($data['to_account_id']);
        abort_unless($toAccount->status === 'active', 422, 'Il conto destinatario non è attivo.');

        $payment = $this->service->create(
            fromAccount:  $currentAccount,
            toAccount:    $toAccount,
            amount:       ky_to_cents($data['amount']),
            description:  $data['description'],
            scheduledAt:  new \DateTime($data['scheduled_at']),
            createdBy:    $currentUser,
        );

        return redirect()
            ->route('portal.scheduled-payments.show', $payment)
            ->with('portal_success', 'Pagamento programmato per ' . \Carbon\Carbon::parse($data['scheduled_at'])->format('d/m/Y H:i') . '.');
    }

    private function storeRecurring(Request $request, Account $currentAccount, User $currentUser): RedirectResponse
    {
        $request->merge(['amount' => str_replace(',', '.', (string) $request->input('amount'))]);

        $data = $request->validate([
            'to_account_id'    => ['required', 'integer', 'exists:accounts,id'],
            'amount'           => ['required', 'numeric', 'min:0.01', 'max:9999999'],
            // max 480 per lasciare spazio al suffisso " (rata XX di XX)" aggiunto dal service
            'description'      => ['required', 'string', 'min:3', 'max:480'],
            'scheduled_at'     => ['required', 'date', 'after:now'],
            'recurrence_type'  => ['required', 'in:monthly,weekly,biweekly'],
            'recurrence_count' => ['required', 'integer', 'min:2', 'max:60'],
        ]);

        abort_if((int) $data['to_account_id'] === $currentAccount->id, 422, 'Non puoi programmare un pagamento a te stesso.');

        $toAccount = Account::findOrFail($data['to_account_id']);
        abort_unless($toAccount->status === 'active', 422, 'Il conto destinatario non è attivo.');

        $payments = $this->service->createRecurring(
            fromAccount:    $currentAccount,
            toAccount:      $toAccount,
            amount:         ky_to_cents($data['amount']),
            description:    $data['description'],
            firstDate:      new \DateTime($data['scheduled_at']),
            recurrenceType: $data['recurrence_type'],
            count:          (int) $data['recurrence_count'],
            createdBy:      $currentUser,
        );

        $total = count($payments);
        $label = match ($data['recurrence_type']) {
            'weekly'   => 'settimanali',
            'biweekly' => 'bisettimanali',
            default    => 'mensili',
        };

        // Email al pagante (chi ha creato il piano)
        if ($currentUser->email) {
            Mail::to($currentUser->email)->queue(new RecurringPaymentScheduled(
                recipient:      $currentUser,
                fromAccount:    $currentAccount,
                toAccount:      $toAccount,
                payments:       $payments,
                recurrenceType: $data['recurrence_type'],
                isPayer:        true,
            ));
        }

        // Email al destinatario (chi riceverà i pagamenti)
        $toUser = $toAccount->ownerUser ?? $toAccount->company?->users()->first();
        if ($toUser && $toUser->email) {
            Mail::to($toUser->email)->queue(new RecurringPaymentScheduled(
                recipient:      $toUser,
                fromAccount:    $currentAccount,
                toAccount:      $toAccount,
                payments:       $payments,
                recurrenceType: $data['recurrence_type'],
                isPayer:        false,
            ));
        }

        return redirect()
            ->route('portal.scheduled-payments.index')
            ->with('portal_success', "Creati {$total} pagamenti ricorrenti {$label} a partire dal " . \Carbon\Carbon::parse($data['scheduled_at'])->format('d/m/Y') . '. Riepilogo inviato via email.');
    }

    // ── Retry ─────────────────────────────────────────────────────────────────

    public function retry(Request $request, ScheduledPayment $scheduledPayment): RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $this->service->retry($scheduledPayment, $currentAccount);

        $scheduledPayment->refresh();

        if ($scheduledPayment->isExecuted()) {
            return redirect()
                ->route('portal.scheduled-payments.show', $scheduledPayment)
                ->with('portal_success', 'Pagamento eseguito con successo.');
        }

        return redirect()
            ->route('portal.scheduled-payments.show', $scheduledPayment)
            ->with('portal_error', 'Pagamento non riuscito: ' . ($scheduledPayment->failure_reason ?? 'errore sconosciuto'));
    }

    // ── CancelGroup ───────────────────────────────────────────────────────────

    public function cancelGroup(Request $request, string $group): RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $pending = \App\Models\ScheduledPayment::where('recurrence_group', $group)
            ->where('from_account_id', $currentAccount->id)
            ->where('status', 'pending')
            ->get();

        abort_if($pending->isEmpty(), 404, 'Nessuna rata in attesa da annullare per questo gruppo.');

        foreach ($pending as $payment) {
            $payment->update(['status' => 'cancelled']);
        }

        $count = $pending->count();

        return redirect()
            ->route('portal.scheduled-payments.index')
            ->with('portal_success', "Annullate {$count} rate ricorrenti rimanenti.");
    }

    // ── Show ──────────────────────────────────────────────────────────────────

    public function show(Request $request, ScheduledPayment $scheduledPayment): View|RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $isSender    = (int) $scheduledPayment->from_account_id === $currentAccount->id;
        $isRecipient = (int) $scheduledPayment->to_account_id   === $currentAccount->id;
        abort_unless($isSender || $isRecipient, 403);

        $scheduledPayment->load(['fromAccount.company', 'toAccount.company', 'transfer', 'creator']);

        return view('portal.scheduled-payments.show', [
            'pageTitle'        => 'Pagamento programmato #' . strtoupper(substr($scheduledPayment->uuid, 0, 8)),
            'currentAccount'   => $currentAccount,
            'payment'          => $scheduledPayment,
            'isSender'         => $isSender,
            'canCancel'        => $isSender && $scheduledPayment->isPending(),
            'activeNav'        => 'scheduled-payments',
        ]);
    }

    // ── Cancel ────────────────────────────────────────────────────────────────

    public function cancel(Request $request, ScheduledPayment $scheduledPayment): RedirectResponse
    {
        [$currentAccount] = $this->resolveCurrentContext($request->user());

        $this->service->cancel($scheduledPayment, $currentAccount);

        return redirect()
            ->route('portal.scheduled-payments.index')
            ->with('portal_success', 'Pagamento programmato annullato.');
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    private function resolveCurrentContext(User $viewer): array
    {
        abort_if($viewer->canAccessBackoffice(), 403);

        // Legacy single-delegate
        if ($viewer->managed_account_id !== null) {
            $account = Account::query()
                ->with(['company', 'ownerUser'])
                ->whereKey($viewer->managed_account_id)
                ->firstOrFail();
            return [$account, $viewer];
        }

        // Multi-account switcher via session
        $sessionAccountId = session('active_account_id');
        if ($sessionAccountId) {
            $switched = Account::query()
                ->with(['company', 'ownerUser'])
                ->where('status', 'active')
                ->find($sessionAccountId);

            if ($switched && $viewer->canOperateOnAccount($switched)) {
                return [$switched, $viewer];
            }

            session()->forget('active_account_id');
        }

        // Account aziendale root
        if ($viewer->company_id !== null) {
            $account = Account::query()
                ->with(['company', 'ownerUser'])
                ->where('company_id', $viewer->company_id)
                ->whereNull('parent_account_id')
                ->where('status', 'active')
                ->orderBy('id')
                ->firstOrFail();
            return [$account, $viewer];
        }

        // Fallback: account personale per utente privato
        $account = Account::query()
            ->with(['company', 'ownerUser'])
            ->where('owner_user_id', $viewer->id)
            ->whereNull('parent_account_id')
            ->where('status', 'active')
            ->orderBy('id')
            ->firstOrFail();

        return [$account, $viewer];
    }
}
