-- =====================================================================
--  Inserimento manuale di 2 movimenti KMoney  (creato il 2026-06-23)
-- =====================================================================
--  Movimenti da registrare (importi in CENTESIMI di KY):
--    1) PW9XRQFYGJ8F  22/06/2026 10:47  @lgasperini      -> @sfizidicarneroma   35,00 KY (3500)
--    2) V2FQFBA5W89U  21/06/2026 15:23  @francescobrogna -> @flavioquiriti     125,00 KY (12500)
--
--  Replica fedelmente cio' che farebbe TransferBookingService::book():
--    - aggiorna available_balance di mittente (-) e destinatario (+)
--    - crea il Transfer (status=booked, kind=trade_payment)
--    - crea le 2 LedgerEntry (debit + credit) con balance_after
--    - scrive un AuditLog (event=transfer.booked)
--  L'invariante di circuito chiuso SUM(saldi)=0 e' preservata: ogni
--  movimento toglie da un conto esattamente cio' che aggiunge all'altro
--  (nessuna emissione dal conto di sistema).
--
--  IDEMPOTENTE: puo' essere eseguito piu' volte senza duplicare nulla
--  (guardie su idempotency_key e su ledger_entries gia' presenti).
--
--  ⚠️  PREREQUISITI:
--    - Selezionare il database di PRODUZIONE in phpMyAdmin
--    - Eseguire PRIMA la query di verifica qui sotto (STEP 0) e
--      controllare che restituisca ESATTAMENTE 4 righe con saldi sensati.
-- =====================================================================


-- ---------------------------------------------------------------------
-- STEP 0 — VERIFICA (eseguire da sola, NON modifica nulla)
-- Deve restituire 4 righe: lgasperini, sfizidicarneroma, francescobrogna, flavioquiriti
-- ---------------------------------------------------------------------
-- SELECT c.slug, a.id AS account_id, a.type, a.owner_type,
--        a.owner_user_id, a.available_balance
-- FROM companies c
-- JOIN accounts a
--   ON a.company_id = c.id
--  AND a.parent_account_id IS NULL
--  AND a.is_system_account = 0
-- WHERE c.slug IN ('lgasperini','sfizidicarneroma','francescobrogna','flavioquiriti')
-- ORDER BY c.slug;


-- =====================================================================
-- MOVIMENTO 1 — PW9XRQFYGJ8F : @lgasperini -> @sfizidicarneroma  35,00 KY
-- =====================================================================
START TRANSACTION;

SET @ref    = 'TRX-PW9XRQFYGJ8F';
SET @idem   = 'manual-import-PW9XRQFYGJ8F';
SET @amount = 3500;
SET @booked = '2026-06-22 10:47:00';
SET @descr  = 'Pagamento nel circuito KMoney';

SET @from_id = (SELECT a.id FROM accounts a JOIN companies c ON c.id = a.company_id
                WHERE c.slug = 'lgasperini'
                  AND a.parent_account_id IS NULL AND a.is_system_account = 0
                ORDER BY a.id LIMIT 1);
SET @to_id   = (SELECT a.id FROM accounts a JOIN companies c ON c.id = a.company_id
                WHERE c.slug = 'sfizidicarneroma'
                  AND a.parent_account_id IS NULL AND a.is_system_account = 0
                ORDER BY a.id LIMIT 1);
SET @from_user = (SELECT owner_user_id FROM accounts WHERE id = @from_id);

-- saldi correnti e saldi risultanti
SET @from_after = (SELECT available_balance FROM accounts WHERE id = @from_id) - @amount;
SET @to_after   = (SELECT available_balance FROM accounts WHERE id = @to_id)   + @amount;

-- inserimento Transfer (solo se i conti esistono e non e' gia' presente)
INSERT INTO transfers
  (uuid, reference, initiated_by, from_account_id, to_account_id, amount,
   currency_code, status, kind, idempotency_key, description, booked_at, created_at, updated_at)
SELECT UUID(), @ref, @from_user, @from_id, @to_id, @amount,
       'KY', 'booked', 'trade_payment', @idem, @descr, @booked, NOW(), NOW()
WHERE @from_id IS NOT NULL AND @to_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM transfers WHERE idempotency_key = @idem);

SET @transfer_id = (SELECT id FROM transfers WHERE idempotency_key = @idem LIMIT 1);
-- @already > 0 => movimento gia' contabilizzato in passato: salta saldi/ledger/audit
SET @already = (SELECT COUNT(*) FROM ledger_entries WHERE transfer_id = @transfer_id);

-- aggiornamento saldi (una sola volta)
UPDATE accounts SET available_balance = @from_after, updated_at = NOW()
WHERE id = @from_id AND @already = 0;
UPDATE accounts SET available_balance = @to_after, updated_at = NOW()
WHERE id = @to_id AND @already = 0;

-- LedgerEntry debit (mittente)
INSERT INTO ledger_entries
  (uuid, transfer_id, account_id, direction, amount, balance_after, posted_at, meta, created_at, updated_at)
SELECT UUID(), @transfer_id, @from_id, 'debit', @amount, @from_after, @booked,
       JSON_OBJECT('counterparty_account_id', @to_id), NOW(), NOW()
WHERE @already = 0;

-- LedgerEntry credit (destinatario)
INSERT INTO ledger_entries
  (uuid, transfer_id, account_id, direction, amount, balance_after, posted_at, meta, created_at, updated_at)
SELECT UUID(), @transfer_id, @to_id, 'credit', @amount, @to_after, @booked,
       JSON_OBJECT('counterparty_account_id', @from_id), NOW(), NOW()
WHERE @already = 0;

-- AuditLog
INSERT INTO audit_logs
  (uuid, actor_user_id, event, auditable_type, auditable_id, ip_address, context, created_at, updated_at)
SELECT UUID(), @from_user, 'transfer.booked', 'App\\Models\\Transfer', @transfer_id, NULL,
       JSON_OBJECT('from_account_id', @from_id, 'to_account_id', @to_id,
                   'amount', @amount, 'currency_code', 'KY',
                   'source', 'manual-import-2026-06-23'),
       NOW(), NOW()
WHERE @already = 0;

COMMIT;


-- =====================================================================
-- MOVIMENTO 2 — V2FQFBA5W89U : @francescobrogna -> @flavioquiriti  125,00 KY
-- =====================================================================
START TRANSACTION;

SET @ref    = 'TRX-V2FQFBA5W89U';
SET @idem   = 'manual-import-V2FQFBA5W89U';
SET @amount = 12500;
SET @booked = '2026-06-21 15:23:00';
SET @descr  = 'Pagamento nel circuito KMoney';

SET @from_id = (SELECT a.id FROM accounts a JOIN companies c ON c.id = a.company_id
                WHERE c.slug = 'francescobrogna'
                  AND a.parent_account_id IS NULL AND a.is_system_account = 0
                ORDER BY a.id LIMIT 1);
SET @to_id   = (SELECT a.id FROM accounts a JOIN companies c ON c.id = a.company_id
                WHERE c.slug = 'flavioquiriti'
                  AND a.parent_account_id IS NULL AND a.is_system_account = 0
                ORDER BY a.id LIMIT 1);
SET @from_user = (SELECT owner_user_id FROM accounts WHERE id = @from_id);

SET @from_after = (SELECT available_balance FROM accounts WHERE id = @from_id) - @amount;
SET @to_after   = (SELECT available_balance FROM accounts WHERE id = @to_id)   + @amount;

INSERT INTO transfers
  (uuid, reference, initiated_by, from_account_id, to_account_id, amount,
   currency_code, status, kind, idempotency_key, description, booked_at, created_at, updated_at)
SELECT UUID(), @ref, @from_user, @from_id, @to_id, @amount,
       'KY', 'booked', 'trade_payment', @idem, @descr, @booked, NOW(), NOW()
WHERE @from_id IS NOT NULL AND @to_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM transfers WHERE idempotency_key = @idem);

SET @transfer_id = (SELECT id FROM transfers WHERE idempotency_key = @idem LIMIT 1);
SET @already = (SELECT COUNT(*) FROM ledger_entries WHERE transfer_id = @transfer_id);

UPDATE accounts SET available_balance = @from_after, updated_at = NOW()
WHERE id = @from_id AND @already = 0;
UPDATE accounts SET available_balance = @to_after, updated_at = NOW()
WHERE id = @to_id AND @already = 0;

INSERT INTO ledger_entries
  (uuid, transfer_id, account_id, direction, amount, balance_after, posted_at, meta, created_at, updated_at)
SELECT UUID(), @transfer_id, @from_id, 'debit', @amount, @from_after, @booked,
       JSON_OBJECT('counterparty_account_id', @to_id), NOW(), NOW()
WHERE @already = 0;

INSERT INTO ledger_entries
  (uuid, transfer_id, account_id, direction, amount, balance_after, posted_at, meta, created_at, updated_at)
SELECT UUID(), @transfer_id, @to_id, 'credit', @amount, @to_after, @booked,
       JSON_OBJECT('counterparty_account_id', @from_id), NOW(), NOW()
WHERE @already = 0;

INSERT INTO audit_logs
  (uuid, actor_user_id, event, auditable_type, auditable_id, ip_address, context, created_at, updated_at)
SELECT UUID(), @from_user, 'transfer.booked', 'App\\Models\\Transfer', @transfer_id, NULL,
       JSON_OBJECT('from_account_id', @from_id, 'to_account_id', @to_id,
                   'amount', @amount, 'currency_code', 'KY',
                   'source', 'manual-import-2026-06-23'),
       NOW(), NOW()
WHERE @already = 0;

COMMIT;


-- ---------------------------------------------------------------------
-- STEP FINALE — CONTROLLO (eseguire dopo l'import)
-- ---------------------------------------------------------------------
-- I due movimenti devono comparire con i rispettivi ledger:
-- SELECT t.reference, t.kind, t.status, t.amount, t.booked_at,
--        fc.slug AS da, tc.slug AS a
-- FROM transfers t
-- JOIN accounts fa ON fa.id=t.from_account_id JOIN companies fc ON fc.id=fa.company_id
-- JOIN accounts ta ON ta.id=t.to_account_id   JOIN companies tc ON tc.id=ta.company_id
-- WHERE t.idempotency_key IN ('manual-import-PW9XRQFYGJ8F','manual-import-V2FQFBA5W89U');
--
-- Invariante di circuito (deve essere 0):
-- SELECT SUM(available_balance) FROM accounts;
