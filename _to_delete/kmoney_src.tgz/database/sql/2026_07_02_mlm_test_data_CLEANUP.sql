-- ============================================================
-- PULIZIA DATI DI TEST MULTILEVEL — elimina tutto il creato da
-- 2026_07_02_mlm_test_data.sql (utenti 900001–900012 e righe MLM).
-- Copre anche righe generate DURANTE i test (prelievi richiesti,
-- promozioni rank, dati bancari, commission base).
-- ============================================================

DELETE FROM mlm_invitations       WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_bonus_payouts     WHERE beneficiary_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_bonus_events      WHERE basiq_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_commissions       WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_commission_runs   WHERE idempotency_key LIKE 'test-mlm-%';
DELETE FROM mlm_payouts           WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_point_ledger      WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_commission_base_ledger WHERE direct_agent_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_rank_history      WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_payment_details   WHERE agent_user_id BETWEEN 900001 AND 900012;
DELETE FROM mlm_agent_closure     WHERE ancestor_id BETWEEN 900001 AND 900012 OR descendant_id BETWEEN 900001 AND 900012;
DELETE FROM users                 WHERE id BETWEEN 900001 AND 900012 AND email LIKE '%@test-mlm.local';

-- NB: eventuali righe in audit_logs generate dai test restano (il log e' immutabile per design).
