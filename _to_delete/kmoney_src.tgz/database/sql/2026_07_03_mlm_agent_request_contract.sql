-- MLM: flusso "diventa agente KNM" — SOLO le parti mancanti (2026-07-03)
-- Verificato su phpMyAdmin produzione (10/07): la migration
--   2026_07_03_100000_add_mlm_agent_request_fields_to_users_table
-- risultava GIA' applicata (colonne su `users` gia' presenti, batch 104).
-- Mancano invece:
--   2026_07_03_100100_create_mlm_agent_contract_signatures_table
--   2026_07_03_100200_add_agent_contract_fields_to_system_settings_table

CREATE TABLE `mlm_agent_contract_signatures` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NOT NULL,
  `contract_version` INT UNSIGNED NOT NULL,
  `contract_html_snapshot` LONGTEXT NOT NULL,
  `signed_at` TIMESTAMP NOT NULL,
  `ip_address` VARCHAR(64) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NULL,
  `updated_at` TIMESTAMP NULL,
  PRIMARY KEY (`id`),
  KEY `mlm_agent_contract_signatures_user_id_foreign` (`user_id`),
  CONSTRAINT `mlm_agent_contract_signatures_user_id_foreign`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `system_settings`
  ADD COLUMN `mlm_agent_contract_text` LONGTEXT NULL,
  ADD COLUMN `mlm_agent_contract_version` INT UNSIGNED NOT NULL DEFAULT 1;

-- Registra le migration come gia' eseguite (2026_07_03_100000 e' gia' in tabella, non reinserirla)
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_07_03_100100_create_mlm_agent_contract_signatures_table', MAX(`batch`) + 1 FROM `migrations`;
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_07_03_100200_add_agent_contract_fields_to_system_settings_table', MAX(`batch`) FROM `migrations` WHERE `migration` = '2026_07_03_100100_create_mlm_agent_contract_signatures_table';
