-- MLM: pagine inviti/alberi/prelievi (2026-07-02)
-- Eseguire su phpMyAdmin produzione. Corrisponde alle migration:
--   2026_07_02_120000_create_mlm_invitations_table
--   2026_07_02_120100_add_requested_at_to_mlm_payouts_table

CREATE TABLE `mlm_invitations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` CHAR(36) NOT NULL,
  `agent_user_id` BIGINT UNSIGNED NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `name` VARCHAR(120) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `registered_user_id` BIGINT UNSIGNED NULL,
  `sent_at` TIMESTAMP NULL,
  `registered_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP NULL,
  `updated_at` TIMESTAMP NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mlm_invitations_uuid_unique` (`uuid`),
  UNIQUE KEY `mlm_invitations_agent_user_id_email_unique` (`agent_user_id`, `email`),
  KEY `mlm_invitations_email_index` (`email`),
  KEY `mlm_invitations_status_index` (`status`),
  CONSTRAINT `mlm_invitations_agent_user_id_foreign` FOREIGN KEY (`agent_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mlm_invitations_registered_user_id_foreign` FOREIGN KEY (`registered_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `mlm_payouts` ADD COLUMN `requested_at` TIMESTAMP NULL AFTER `status`;

-- Registra le migration come gia' eseguite (evita che un futuro `migrate` le riproponga)
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_07_02_120000_create_mlm_invitations_table', MAX(`batch`) + 1 FROM `migrations`;
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_07_02_120100_add_requested_at_to_mlm_payouts_table', MAX(`batch`) + 1 FROM `migrations`;
