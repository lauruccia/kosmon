-- ─────────────────────────────────────────────────────────────────────────
-- KMoney · Settori gerarchici (sotto-settori a più livelli)
-- Aggiunge la colonna auto-referenziale `parent_id` alla tabella `sectors`.
-- Eseguire su PRODUZIONE (MySQL) tramite phpMyAdmin.
-- ─────────────────────────────────────────────────────────────────────────

ALTER TABLE `sectors`
  ADD COLUMN `parent_id` BIGINT UNSIGNED NULL DEFAULT NULL AFTER `id`,
  ADD CONSTRAINT `sectors_parent_id_foreign`
      FOREIGN KEY (`parent_id`) REFERENCES `sectors` (`id`) ON DELETE SET NULL;

-- (Opzionale) registra la migration come eseguita, così `php artisan migrate`
-- non tenta di rilanciarla. Allinea il valore di `batch` all'ultimo presente.
-- INSERT INTO `migrations` (`migration`, `batch`)
-- VALUES ('2026_06_30_120000_add_parent_id_to_sectors_table',
--         (SELECT COALESCE(MAX(b), 0) + 1 FROM (SELECT MAX(batch) AS b FROM migrations) t));
