-- ============================================================
-- DATI DI TEST MULTILEVEL (MLM) — 2026-07-02
-- Albero agenti con tutte le qualifiche/colori, clienti, punti,
-- commissioni+bonus maturati (per provare il prelievo), inviti.
-- ID riservati: utenti 900001–900012 (email @test-mlm.local).
-- Password di tutti gli utenti test: TestMlm2026!
-- PER ELIMINARE: eseguire 2026_07_02_mlm_test_data_CLEANUP.sql
-- ============================================================

-- ---------- UTENTI: 9 agenti (una qualifica per colore) + 3 clienti ----------
INSERT INTO users (id, name, email, email_verified_at, password, role, is_active, is_super_admin, account_holder_type, referral_code, referred_by_user_id, mlm_role, mlm_rank, mlm_activated_at, mlm_client_agent_id, created_at, updated_at) VALUES
(900001, 'TEST Manager Radice', 'manager@test-mlm.local',    CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML01', NULL,   'agente', 'manager',    CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 'TEST Senior Uno',     'senior@test-mlm.local',     CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML02', 900001, 'agente', 'senior',     CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900003, 'TEST Top Uno',        'top@test-mlm.local',        CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML03', 900001, 'agente', 'top',        CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900004, 'TEST Basic Uno',      'basic@test-mlm.local',      CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML04', 900002, 'agente', 'basic',      CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900005, 'TEST Key Uno',        'key@test-mlm.local',        CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML05', 900002, 'agente', 'key',        CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900006, 'TEST Start Uno',      'start1@test-mlm.local',     CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML06', 900004, 'agente', 'start',      CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900007, 'TEST Start Due',      'start2@test-mlm.local',     CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML07', 900004, 'agente', 'start',      CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900008, 'TEST Start Tre',      'start3@test-mlm.local',     CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML08', 900003, 'agente', 'start',      CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900009, 'TEST SuperVisor Uno', 'supervisor@test-mlm.local', CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', 'TESTML09', 900001, 'agente', 'supervisor', CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900010, 'TEST Cliente Uno',    'cliente1@test-mlm.local',   CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', NULL,       900004, 'cliente', 'start',     NULL,              900004, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900011, 'TEST Cliente Due',    'cliente2@test-mlm.local',   CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', NULL,       900004, 'cliente', 'start',     NULL,              900004, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900012, 'TEST Cliente Tre',    'cliente3@test-mlm.local',   CURRENT_TIMESTAMP, '$2y$10$GVDf4j4qOUS86BPBYZcjB.cMMrDTWCjb3Ek4aSaVCUcupb7ov7Tpe', 'registered-private', 1, 0, 'private', NULL,       900002, 'cliente', 'start',     NULL,              900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- ---------- ALBERO (closure table) ----------
-- Struttura: 900001 ─ (900002 ─ (900004 ─ (900006, 900007), 900005), 900003 ─ 900008, 900009)
-- Righe self (depth 0)
INSERT INTO mlm_agent_closure (ancestor_id, descendant_id, depth, branch_root_id, created_at, updated_at) VALUES
(900001, 900001, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 900002, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900003, 900003, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900004, 900004, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900005, 900005, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900006, 900006, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900007, 900007, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900008, 900008, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900009, 900009, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
-- Righe antenato→discendente (branch_root_id = figlio diretto dell'antenato sul percorso)
INSERT INTO mlm_agent_closure (ancestor_id, descendant_id, depth, branch_root_id, created_at, updated_at) VALUES
(900001, 900002, 1, 900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900003, 1, 900003, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900009, 1, 900009, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900004, 2, 900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900005, 2, 900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900008, 2, 900003, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900006, 3, 900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900001, 900007, 3, 900002, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 900004, 1, 900004, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 900005, 1, 900005, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 900006, 2, 900004, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900002, 900007, 2, 900004, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900004, 900006, 1, 900006, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900004, 900007, 1, 900007, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
(900003, 900008, 1, 900008, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- ---------- PUNTI ATTIVI (validi 12 mesi da oggi) ----------
INSERT INTO mlm_point_ledger (uuid, agent_user_id, client_user_id, source_type, points, valid_from, valid_until, created_at, updated_at) VALUES
('test0000-0000-0000-0000-000000000001', 900001, 900012, 'deposit',      48, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000002', 900002, 900012, 'deposit',      36, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000003', 900002, 900012, 'registration',  1, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000004', 900004, 900010, 'deposit',      12, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000005', 900004, 900011, 'deposit',      10, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000006', 900005, 900011, 'deposit',      24, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000007', 900003, 900010, 'deposit',      30, '2026-07-01', '2027-06-30', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- ---------- MATURATO per TEST Senior (900002): 120 EUR commissioni + 60 EUR bonus ----------
INSERT INTO mlm_commission_runs (uuid, period_month, idempotency_key, status, started_at, completed_at, created_at, updated_at) VALUES
('test0000-0000-0000-0000-000000000010', '2025-12-01', 'test-mlm-run-1', 'completed', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO mlm_commissions (uuid, mlm_commission_run_id, agent_user_id, type, source_client_id, source_agent_id, level, base_amount_eur_cents, percentage, amount_eur_cents, status, idempotency_key, created_at, updated_at)
SELECT 'test0000-0000-0000-0000-000000000011', id, 900002, 'diretta', 900012, NULL, NULL, 120000, 10.000, 12000, 'pending', 'test-mlm-comm-1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM mlm_commission_runs WHERE idempotency_key = 'test-mlm-run-1';

INSERT INTO mlm_bonus_events (uuid, basiq_user_id, triggered_at, status, created_at, updated_at) VALUES
('test0000-0000-0000-0000-000000000012', 900004, CURRENT_TIMESTAMP, 'processed', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO mlm_bonus_payouts (uuid, mlm_bonus_event_id, beneficiary_user_id, rank_at_time, amount_eur_cents, week_ending, status, idempotency_key, created_at, updated_at)
SELECT 'test0000-0000-0000-0000-000000000013', id, 900002, 'senior', 6000, '2026-07-01', 'pending', 'test-mlm-bonus-1', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
FROM mlm_bonus_events WHERE uuid = 'test0000-0000-0000-0000-000000000012';

-- ---------- INVITI di TEST Senior (900002) ----------
INSERT INTO mlm_invitations (uuid, agent_user_id, email, name, status, registered_user_id, sent_at, registered_at, created_at, updated_at) VALUES
('test0000-0000-0000-0000-000000000014', 900002, 'in-attesa@test-mlm.local',  'Mario In Attesa', 'pending',    NULL,   CURRENT_TIMESTAMP, NULL,              CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('test0000-0000-0000-0000-000000000015', 900002, 'cliente3@test-mlm.local',   'Cliente Tre',     'registered', 900012, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
