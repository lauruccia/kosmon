-- ============================================================================
-- Card NFC per tutti i partecipanti (aziende + privati)
-- Da applicare in PRODUZIONE via phpMyAdmin.
-- Corrisponde alla migration: 2026_06_30_120000_add_owner_user_id_to_nfc_cards
-- ============================================================================

-- 1) Aggiunge owner_user_id (titolare privato), nullable, FK su users
ALTER TABLE `nfc_cards`
    ADD COLUMN `owner_user_id` BIGINT UNSIGNED NULL AFTER `company_id`,
    ADD CONSTRAINT `nfc_cards_owner_user_id_foreign`
        FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- 2) Rende company_id nullable (i privati non hanno azienda)
ALTER TABLE `nfc_cards`
    MODIFY `company_id` BIGINT UNSIGNED NULL;

-- 3) Registra la migration come eseguita (così artisan non la riesegue)
--    Aggiorna il numero di batch se necessario (MAX(batch) della tabella).
INSERT INTO `migrations` (`migration`, `batch`)
SELECT '2026_06_30_120000_add_owner_user_id_to_nfc_cards', COALESCE(MAX(`batch`), 0) + 1
FROM `migrations`;
