@extends('layouts.portal')

@section('content')
<div class="stack">

    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
        <div>
            <h1 style="font-size:22px;font-weight:800;color:var(--ink);margin:0;">Card NFC Fisiche</h1>
            <p style="font-size:13px;color:var(--ink-muted);margin:4px 0 0;">Emissione, consegna e revoca card per i clienti.</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <a href="{{ route('admin.nfc-cards.create') }}" class="cta secondary" style="font-size:13px;padding:9px 18px;">
                &#43; Card singola
            </a>
            <a href="{{ route('admin.nfc-cards.bulk-create') }}" class="cta" style="font-size:13px;padding:9px 18px;">
                &#43; Emissione bulk
            </a>
        </div>
    </div>

    {{-- Stats rapide --}}
    @if(isset($stats))
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;">
        @foreach([
            ['label'=>'Totali',    'value'=>$stats['total'],     'color'=>'#6b7280'],
            ['label'=>'Pending',   'value'=>$stats['pending'],   'color'=>'#d97706'],
            ['label'=>'Emesse',    'value'=>$stats['issued'],    'color'=>'#2563eb'],
            ['label'=>'Spedite',   'value'=>$stats['shipped'],   'color'=>'#7c3aed'],
            ['label'=>'Consegnate','value'=>$stats['delivered'], 'color'=>'#0891b2'],
            ['label'=>'Attive',    'value'=>$stats['active'],    'color'=>'#16a34a'],
        ] as $s)
        <div style="background:var(--surface);border:1.5px solid var(--line);border-radius:10px;padding:12px 14px;">
            <div style="font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:{{ $s['color'] }};margin-bottom:4px;">{{ $s['label'] }}</div>
            <div style="font-size:22px;font-weight:900;color:{{ $s['color'] }};">{{ $s['value'] }}</div>
        </div>
        @endforeach
    </div>
    @endif

    {{-- Filtri --}}
    <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cerca azienda..."
               style="flex:1;min-width:160px;border:1px solid var(--line);border-radius:8px;padding:8px 12px;font-size:13px;background:var(--surface-soft);color:var(--ink);">
        <select name="status" style="flex:1;min-width:140px;border:1px solid var(--line);border-radius:8px;padding:8px 12px;font-size:13px;background:var(--surface-soft);color:var(--ink);">
            <option value="">Tutti gli stati</option>
            @foreach(['pending','issued','delivered','active','blocked','revoked'] as $s)
                <option value="{{ $s }}" @selected(request('status') === $s)>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <button type="submit" class="cta secondary" style="font-size:13px;padding:8px 16px;width:100%;">Filtra</button>
    </form>

    <section class="card" style="overflow-x:auto;">
        <table style="width:100%;min-width:560px;border-collapse:collapse;font-size:13px;">
            <thead>
                <tr style="border-bottom:1px solid var(--line);background:var(--surface-soft);">
                    <th style="padding:10px 16px;text-align:left;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;white-space:nowrap;">Seriale</th>
                    <th style="padding:10px 16px;text-align:left;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;white-space:nowrap;">Cliente</th>
                    <th style="padding:10px 16px;text-align:left;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;white-space:nowrap;">Stato</th>
                    <th style="padding:10px 16px;text-align:left;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;white-space:nowrap;">Emessa</th>
                    <th style="padding:10px 16px;text-align:left;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;white-space:nowrap;">Ultimo uso</th>
                    <th style="padding:10px 16px;text-align:right;font-weight:700;color:var(--ink-muted);text-transform:uppercase;font-size:11px;letter-spacing:.06em;"></th>
                </tr>
            </thead>
            <tbody>
                @forelse($cards as $card)
                    @php
                        $statusColors = [
                            'pending'   => ['bg'=>'#fef9c3','color'=>'#854d0e'],
                            'issued'    => ['bg'=>'#dbeafe','color'=>'#1e40af'],
                            'delivered' => ['bg'=>'#ede9fe','color'=>'#6d28d9'],
                            'active'    => ['bg'=>'#dcfce7','color'=>'#166534'],
                            'blocked'   => ['bg'=>'#fee2e2','color'=>'#991b1b'],
                            'revoked'   => ['bg'=>'#f3f4f6','color'=>'#6b7280'],
                        ];
                        $sc = $statusColors[$card->status] ?? ['bg'=>'#f3f4f6','color'=>'#374151'];
                    @endphp
                    <tr style="border-bottom:1px solid var(--line);">
                        <td style="padding:12px 16px;font-weight:600;color:var(--ink);font-family:monospace;white-space:nowrap;">
                            {{ $card->serial_number ?? substr($card->uuid, 0, 8) }}
                        </td>
                        <td style="padding:12px 16px;color:var(--ink);">{{ $card->ownerName() }}</td>
                        <td style="padding:12px 16px;white-space:nowrap;">
                            <span style="display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:{{ $sc['bg'] }};color:{{ $sc['color'] }};">
                                {{ strtoupper($card->status) }}
                            </span>
                        </td>
                        <td style="padding:12px 16px;color:var(--ink-muted);white-space:nowrap;">{{ $card->issued_at?->format('d/m/Y') ?? '—' }}</td>
                        <td style="padding:12px 16px;color:var(--ink-muted);white-space:nowrap;">{{ $card->last_used_at?->diffForHumans() ?? 'Mai' }}</td>
                        <td style="padding:12px 16px;text-align:right;white-space:nowrap;">
                            <a href="{{ route('admin.nfc-cards.show', $card) }}" style="font-size:12px;font-weight:600;color:var(--primary);">Gestisci</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" style="padding:32px;text-align:center;color:var(--ink-muted);">Nessuna card emessa.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </section>

    {{ $cards->links() }}

</div>
@endsection
